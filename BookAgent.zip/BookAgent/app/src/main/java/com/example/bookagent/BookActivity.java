package com.example.bookagent;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class BookActivity extends Fragment {

    private RecyclerView recyclerView;
    private FloatingActionButton fabAddBook;
    private List<Book> bookList;
    private BookAdapter adapter;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_book, container, false);

        recyclerView = view.findViewById(R.id.recyclerBooks);
        fabAddBook = view.findViewById(R.id.fabAddBook);

        //Khởi tạo database
        dbHelper = new DatabaseHelper(getContext());
        bookList = dbHelper.getAllBooks();

        // Nếu database trống thì thêm dữ liệu mẫu
        if (bookList.isEmpty()) {
            bookList.add(new Book("Lập trình Java cơ bản", 10, 55000));
            bookList.add(new Book("Cấu trúc dữ liệu và giải thuật", 7, 75000));
            bookList.add(new Book("Trí tuệ nhân tạo", 5, 92000));
            for (Book b : bookList) dbHelper.addBook(b);
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new BookAdapter(bookList, this::showEditDialog, this::deleteBook);
        recyclerView.setAdapter(adapter);

        fabAddBook.setOnClickListener(v -> showAddDialog());

        return view;
    }

    //THÊM SÁCH
    private void showAddDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_book, null);
        EditText edtTitle = dialogView.findViewById(R.id.edtBookTitle);
        EditText edtQuantity = dialogView.findViewById(R.id.edtBookQuantity);
        EditText edtPrice = dialogView.findViewById(R.id.edtBookPrice);

        new AlertDialog.Builder(getContext())
                .setTitle("Thêm sách mới")
                .setView(dialogView)
                .setPositiveButton("Thêm", (dialog, which) -> {
                    String title = edtTitle.getText().toString().trim();
                    String qtyStr = edtQuantity.getText().toString().trim();
                    String priceStr = edtPrice.getText().toString().trim();

                    if (!title.isEmpty() && !qtyStr.isEmpty() && !priceStr.isEmpty()) {
                        int qty = Integer.parseInt(qtyStr);
                        double price = Double.parseDouble(priceStr);
                        Book newBook = new Book(title, qty, price);
                        dbHelper.addBook(newBook); //
                        bookList.add(newBook);
                        adapter.notifyItemInserted(bookList.size() - 1);
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    //SỬA SÁCH
    private void showEditDialog(int position) {
        Book book = bookList.get(position);

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_book, null);
        EditText edtTitle = dialogView.findViewById(R.id.edtBookTitle);
        EditText edtQuantity = dialogView.findViewById(R.id.edtBookQuantity);
        EditText edtPrice = dialogView.findViewById(R.id.edtBookPrice);

        edtTitle.setText(book.getTitle());
        edtQuantity.setText(String.valueOf(book.getQuantity()));
        edtPrice.setText(String.valueOf(book.getPrice()));
        edtQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);
        edtPrice.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);

        new AlertDialog.Builder(getContext())
                .setTitle("Sửa thông tin sách")
                .setView(dialogView)
                .setPositiveButton("Lưu", (dialog, which) -> {
                    String newTitle = edtTitle.getText().toString().trim();
                    String newQtyStr = edtQuantity.getText().toString().trim();
                    String newPriceStr = edtPrice.getText().toString().trim();

                    if (!newTitle.isEmpty() && !newQtyStr.isEmpty() && !newPriceStr.isEmpty()) {
                        Book oldBook = new Book(book.getTitle(), book.getQuantity(), book.getPrice());
                        book.setTitle(newTitle);
                        book.setQuantity(Integer.parseInt(newQtyStr));
                        book.setPrice(Double.parseDouble(newPriceStr));
                        dbHelper.updateBook(oldBook, book);
                        adapter.notifyItemChanged(position);
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    //XÓA SÁCH (CHỌN SỐ LƯỢNG)
    private void deleteBook(int position) {
        Book book = bookList.get(position);
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_delete_book, null);
        TextView tvTitle = dialogView.findViewById(R.id.tvDeleteTitle);
        EditText edtQuantity = dialogView.findViewById(R.id.edtDeleteQuantity);
        Button btnMinus = dialogView.findViewById(R.id.btnMinus);
        Button btnPlus = dialogView.findViewById(R.id.btnPlus);

        tvTitle.setText("Xóa sách: " + book.getTitle());
        edtQuantity.setText("1");

        btnMinus.setOnClickListener(v -> {
            int current = Integer.parseInt(edtQuantity.getText().toString());
            if (current > 1) edtQuantity.setText(String.valueOf(current - 1));
        });

        btnPlus.setOnClickListener(v -> {
            int current = Integer.parseInt(edtQuantity.getText().toString());
            if (current < book.getQuantity()) edtQuantity.setText(String.valueOf(current + 1));
        });

        new AlertDialog.Builder(getContext())
                .setTitle("Xóa sách khỏi kho")
                .setView(dialogView)
                .setPositiveButton("Xóa", (dialog, which) -> {
                    int qtyToDelete = Integer.parseInt(edtQuantity.getText().toString());
                    int remaining = book.getQuantity() - qtyToDelete;

                    if (remaining <= 0) {
                        dbHelper.deleteBook(book.getTitle());
                        bookList.remove(position);
                    } else {
                        book.setQuantity(remaining);
                        dbHelper.updateBook(book, book);
                    }
                    adapter.notifyDataSetChanged();
                    Toast.makeText(getContext(), "Đã xóa " + qtyToDelete + " sách.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

}
