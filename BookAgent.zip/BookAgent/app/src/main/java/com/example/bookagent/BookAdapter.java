package com.example.bookagent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> books;
    private OnEditListener editListener;
    private OnDeleteListener deleteListener;

    public interface OnEditListener {
        void onEdit(int position);
    }

    public interface OnDeleteListener {
        void onDelete(int position);
    }

    public BookAdapter(List<Book> books, OnEditListener editListener, OnDeleteListener deleteListener) {
        this.books = books;
        this.editListener = editListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_book, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);
        holder.txtBookTitle.setText(book.getTitle());
        holder.txtBookInfo.setText("Số lượng: " + book.getQuantity() + " | Giá: " + book.getPrice() + "đ");

        holder.btnEdit.setOnClickListener(v -> editListener.onEdit(position));
        holder.btnDelete.setOnClickListener(v -> deleteListener.onDelete(position));
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView txtBookTitle, txtBookInfo;
        ImageButton btnEdit, btnDelete;

        BookViewHolder(View itemView) {
            super(itemView);
            txtBookTitle = itemView.findViewById(R.id.txtBookTitle);
            txtBookInfo = itemView.findViewById(R.id.txtBookInfo);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
