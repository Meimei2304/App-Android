package com.example.bookagent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookSaleAdapter extends RecyclerView.Adapter<BookSaleAdapter.VH> {

    public interface OnAddToCart {
        void onAdd(int position, int qtySelected);
    }

    private List<Book> books;
    private OnAddToCart addListener;
    public BookSaleAdapter(List<Book> books, OnAddToCart listener) {
        this.books = books;
        this.addListener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sale, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Book b = books.get(position);
        holder.tvTitle.setText(b.getTitle());
        holder.tvInfo.setText("Giá: " + b.getPrice() + "đ | Tồn: " + b.getQuantity() + (b.getQuantity() == 0 ? " (Hết hàng)" : ""));
        holder.qty = 0;
        holder.tvQty.setText(String.valueOf(holder.qty));

        holder.btnPlus.setOnClickListener(v -> {
            if (holder.qty < b.getQuantity()) {
                holder.qty++;
                holder.tvQty.setText(String.valueOf(holder.qty));
            }
        });
        holder.btnMinus.setOnClickListener(v -> {
            if (holder.qty > 0) {
                holder.qty--;
                holder.tvQty.setText(String.valueOf(holder.qty));
            }
        });
        holder.btnAdd.setOnClickListener(v -> {
            if (holder.qty > 0) addListener.onAdd(position, holder.qty);
        });
    }

    @Override
    public int getItemCount() { return books.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvInfo, tvQty;
        ImageButton btnPlus, btnMinus;
        Button btnAdd;
        int qty = 0;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitleSale);
            tvInfo = itemView.findViewById(R.id.tvInfoSale);
            tvQty = itemView.findViewById(R.id.tvQtySelected);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnAdd = itemView.findViewById(R.id.btnAddToCart);
        }
    }
}
