package com.example.bookagent;

import android.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.VH> {

    public interface CartActions {
        void onRemove(int pos);
        void onUpdateQty(int pos, int newQty);
    }

    private List<SaleActivity.CartItem> cart;
    private CartActions actions;
    public CartAdapter(List<SaleActivity.CartItem> cart, CartActions actions) {
        this.cart = cart;
        this.actions = actions;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        SaleActivity.CartItem item = cart.get(position);
        holder.tvTitle.setText(item.title);
        holder.tvInfo.setText("SL: " + item.quantity + " | Giá: " + item.price + "đ | Thành tiền: " + (item.quantity * item.price) + "đ");

        holder.btnRemove.setOnClickListener(v -> {
            actions.onRemove(position);
        });

        holder.itemView.setOnLongClickListener(v -> {
            // Chỉnh số lượng
            AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
            final EditText input = new EditText(v.getContext());
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
            input.setText(String.valueOf(item.quantity));
            builder.setTitle("Cập nhật số lượng")
                    .setView(input)
                    .setPositiveButton("OK", (d, w) -> {
                        String s = input.getText().toString();
                        if (!s.isEmpty()) {
                            int newQ = Integer.parseInt(s);
                            if (newQ <= 0) {
                                Toast.makeText(v.getContext(), "Số lượng phải > 0", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            actions.onUpdateQty(position, newQ);
                        }
                    })
                    .setNegativeButton("Hủy", null)
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() { return cart.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvInfo;
        Button btnRemove;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvCartTitle);
            tvInfo = itemView.findViewById(R.id.tvCartInfo);
            btnRemove = itemView.findViewById(R.id.btnRemoveCart);
        }
    }
}
