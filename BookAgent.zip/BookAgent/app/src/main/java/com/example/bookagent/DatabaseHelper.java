package com.example.bookagent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    //CẤU HÌNH CƠ BẢN
    private static final String DATABASE_NAME = "BookAgent.db";
    private static final int DATABASE_VERSION = 5; //tăng version để cập nhật lại DB

    //BẢNG SÁCH
    private static final String TABLE_BOOKS = "books";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_PRICE = "price";

    //BẢNG HÓA ĐƠN
    private static final String TABLE_HOADON = "HoaDon";
    private static final String HD_ID = "id";
    private static final String HD_DATE = "date";
    private static final String HD_TOTAL = "total";

    //BẢNG CHI TIẾT HÓA ĐƠN
    private static final String TABLE_CHITIET = "ChiTietHoaDon";
    private static final String CT_ID = "id";
    private static final String CT_HOADON_ID = "hoadon_id";
    private static final String CT_BOOK_TITLE = "book_title";
    private static final String CT_QUANTITY = "quantity";
    private static final String CT_PRICE = "price";
    private static final String CT_SUBTOTAL = "subtotal";

    //BẢNG PHIẾU NHẬP
    private static final String TABLE_IMPORT_RECEIPTS = "import_receipts";
    private static final String TABLE_IMPORT_ITEMS = "import_items";

    //CONSTRUCTOR
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //TẠO CSDL LẦN ĐẦU
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Bảng Sách (kho bán)
        db.execSQL("CREATE TABLE " + TABLE_BOOKS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_QUANTITY + " INTEGER, " +
                COLUMN_PRICE + " REAL)");

        // Bảng Hóa đơn
        db.execSQL("CREATE TABLE " + TABLE_HOADON + " (" +
                HD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                HD_DATE + " TEXT, " +
                HD_TOTAL + " REAL)");

        // Bảng Chi tiết hóa đơn
        db.execSQL("CREATE TABLE " + TABLE_CHITIET + " (" +
                CT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CT_HOADON_ID + " INTEGER, " +
                CT_BOOK_TITLE + " TEXT, " +
                CT_QUANTITY + " INTEGER, " +
                CT_PRICE + " REAL, " +
                CT_SUBTOTAL + " REAL, " +
                "FOREIGN KEY(" + CT_HOADON_ID + ") REFERENCES " + TABLE_HOADON + "(" + HD_ID + "))");

        // Bảng Phiếu nhập (chỉ lưu thông tin nhập hàng)
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_IMPORT_RECEIPTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "provider_name TEXT, " +
                "import_date TEXT, " +
                "total REAL)");

        // Chi tiết phiếu nhập
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_IMPORT_ITEMS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "receipt_id INTEGER, " +
                "book_title TEXT, " +
                "quantity INTEGER, " +
                "price REAL, " +
                "subtotal REAL, " +
                "FOREIGN KEY(receipt_id) REFERENCES " + TABLE_IMPORT_RECEIPTS + "(id))");
    }

    //NÂNG CẤP CSDL
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHITIET);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HOADON);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_IMPORT_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_IMPORT_RECEIPTS);
        onCreate(db);
    }

    //CÁC HÀM XỬ LÝ SÁCH
    public void addBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_QUANTITY, book.getQuantity());
        values.put(COLUMN_PRICE, book.getPrice());
        db.insert(TABLE_BOOKS, null, values);
        db.close();
    }

    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_BOOKS, null);
        if (cursor.moveToFirst()) {
            do {
                books.add(new Book(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PRICE))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return books;
    }

    public void updateBook(Book oldBook, Book newBook) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, newBook.getTitle());
        values.put(COLUMN_QUANTITY, newBook.getQuantity());
        values.put(COLUMN_PRICE, newBook.getPrice());
        db.update(TABLE_BOOKS, values,
                COLUMN_TITLE + "=? AND " + COLUMN_PRICE + "=?",
                new String[]{oldBook.getTitle(), String.valueOf(oldBook.getPrice())});
        db.close();
    }

    public void deleteBook(String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_BOOKS, COLUMN_TITLE + "=?", new String[]{title});
        db.close();
    }

    public Book getBookByTitle(String title) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_BOOKS,
                new String[]{COLUMN_TITLE, COLUMN_QUANTITY, COLUMN_PRICE},
                COLUMN_TITLE + "=?", new String[]{title},
                null, null, null);
        Book book = null;
        if (cursor != null && cursor.moveToFirst()) {
            book = new Book(
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PRICE))
            );
            cursor.close();
        }
        db.close();
        return book;
    }

    public int updateBookQuantityByTitle(String title, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);
        int rows = db.update(TABLE_BOOKS, values, COLUMN_TITLE + "=?", new String[]{title});
        db.close();
        return rows;
    }

    // ====== HÓA ĐƠN ======
    public long addInvoice(String dateString, double total) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(HD_DATE, dateString);
        values.put(HD_TOTAL, total);
        long id = db.insert(TABLE_HOADON, null, values);
        db.close();
        return id;
    }

    public long addInvoiceDetail(long hoadonId, String bookTitle, int qty, double price, double subtotal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CT_HOADON_ID, hoadonId);
        values.put(CT_BOOK_TITLE, bookTitle);
        values.put(CT_QUANTITY, qty);
        values.put(CT_PRICE, price);
        values.put(CT_SUBTOTAL, subtotal);
        long id = db.insert(TABLE_CHITIET, null, values);
        db.close();
        return id;
    }

    public List<String> getAllInvoices() {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_HOADON, null);
        if (cursor.moveToFirst()) {
            do {
                list.add("Hóa đơn #" + cursor.getInt(cursor.getColumnIndexOrThrow(HD_ID)) +
                        " - Tổng: " + cursor.getDouble(cursor.getColumnIndexOrThrow(HD_TOTAL)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    // ====== PHIẾU NHẬP ======
    public void addImportReceipt(ImportReceipt receipt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("provider_name", receipt.getProvider());
        values.put("import_date", receipt.getDate());
        values.put("total", receipt.getTotal());
        long receiptId = db.insert(TABLE_IMPORT_RECEIPTS, null, values);

        // Chỉ lưu phiếu nhập, KHÔNG cập nhật vào bảng books
        for (ImportItem item : receipt.getItems()) {
            ContentValues itemValues = new ContentValues();
            itemValues.put("receipt_id", receiptId);
            itemValues.put("book_title", item.getBookTitle());
            itemValues.put("quantity", item.getQuantity());
            itemValues.put("price", item.getPrice());
            itemValues.put("subtotal", item.getSubtotal());
            db.insert(TABLE_IMPORT_ITEMS, null, itemValues);
        }
        db.close();
    }

    public List<ImportReceipt> getAllImportReceipts() {
        List<ImportReceipt> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_IMPORT_RECEIPTS, null);
        if (c.moveToFirst()) {
            do {
                int id = c.getInt(c.getColumnIndexOrThrow("id"));
                String provider = c.getString(c.getColumnIndexOrThrow("provider_name"));
                String date = c.getString(c.getColumnIndexOrThrow("import_date"));
                double total = c.getDouble(c.getColumnIndexOrThrow("total"));

                List<ImportItem> items = new ArrayList<>();
                Cursor ci = db.rawQuery("SELECT * FROM " + TABLE_IMPORT_ITEMS + " WHERE receipt_id=?",
                        new String[]{String.valueOf(id)});
                if (ci.moveToFirst()) {
                    do {
                        items.add(new ImportItem(
                                ci.getString(ci.getColumnIndexOrThrow("book_title")),
                                ci.getInt(ci.getColumnIndexOrThrow("quantity")),
                                ci.getDouble(ci.getColumnIndexOrThrow("price"))
                        ));
                    } while (ci.moveToNext());
                }
                ci.close();

                ImportReceipt r = new ImportReceipt(provider, date, total, items);
                r.setId(id);
                list.add(r);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public void deleteImportReceipt(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_IMPORT_ITEMS, "receipt_id=?", new String[]{String.valueOf(id)});
        db.delete(TABLE_IMPORT_RECEIPTS, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

}
