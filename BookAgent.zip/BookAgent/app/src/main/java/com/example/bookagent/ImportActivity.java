package com.example.bookagent;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ImportActivity extends Fragment {

    private RecyclerView recyclerView;
    private FloatingActionButton fabAddImport;
    private ImportAdapter adapter;
    private List<ImportReceipt> importList;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_import, container, false);

        recyclerView = view.findViewById(R.id.recyclerImportReceipts);
        fabAddImport = view.findViewById(R.id.fabAddImport);

        dbHelper = new DatabaseHelper(getContext());
        importList = dbHelper.getAllImportReceipts();

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ImportAdapter(importList, this::showDetailDialog, this::deleteImport);
        recyclerView.setAdapter(adapter);

        fabAddImport.setOnClickListener(v -> showAddImportDialog());

        return view;
    }

    // ===================== TẠO PHIẾU NHẬP MỚI =====================
    private void showAddImportDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_import, null);
        EditText edtProvider = dialogView.findViewById(R.id.edtProvider);
        EditText edtDate = dialogView.findViewById(R.id.edtDate);
        TextView txtTotal = dialogView.findViewById(R.id.txtTotalImport);
        Button btnAddBook = dialogView.findViewById(R.id.btnAddBookToImport);

        List<ImportItem> items = new ArrayList<>();
        final double[] total = {0.0};

        // Gợi ý ngày hiện tại
        String today = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        edtDate.setText(today);

        btnAddBook.setOnClickListener(v -> showAddBookDialog(items, txtTotal, total));

        new AlertDialog.Builder(getContext())
                .setTitle("Tạo phiếu nhập mới")
                .setView(dialogView)
                .setPositiveButton("Lưu phiếu", (dialog, which) -> {
                    String provider = edtProvider.getText().toString().trim();
                    String date = edtDate.getText().toString().trim();

                    if (provider.isEmpty() || items.isEmpty()) {
                        Toast.makeText(getContext(), "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ImportReceipt receipt = new ImportReceipt(provider, date, total[0], items);
                    dbHelper.addImportReceipt(receipt);
                    importList.add(receipt);
                    adapter.notifyItemInserted(importList.size() - 1);


                    Toast.makeText(getContext(), "Đã lưu phiếu nhập", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    // ===================== THÊM SÁCH VÀO PHIẾU =====================
    private void showAddBookDialog(List<ImportItem> items, TextView txtTotal, double[] total) {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_book_import, null);
        EditText edtTitle = dialogView.findViewById(R.id.edtBookTitleImport);
        EditText edtQty = dialogView.findViewById(R.id.edtBookQuantityImport);
        EditText edtPrice = dialogView.findViewById(R.id.edtBookPriceImport);

        new AlertDialog.Builder(getContext())
                .setTitle("Thêm sách vào phiếu")
                .setView(dialogView)
                .setPositiveButton("Thêm", (dialog, which) -> {
                    String title = edtTitle.getText().toString().trim();
                    String qtyStr = edtQty.getText().toString().trim();
                    String priceStr = edtPrice.getText().toString().trim();

                    if (title.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
                        Toast.makeText(getContext(), "Nhập đủ thông tin sách", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty = Integer.parseInt(qtyStr);
                    double price = Double.parseDouble(priceStr);

                    ImportItem item = new ImportItem(title, qty, price);
                    items.add(item);
                    total[0] += item.getSubtotal();
                    txtTotal.setText("Tổng tiền: " + String.format("%,.0fđ", total[0]));
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    // ===================== XEM CHI TIẾT PHIẾU =====================
    private void showDetailDialog(ImportReceipt receipt) {
        StringBuilder details = new StringBuilder();

        for (ImportItem item : receipt.getItems()) {
            details.append("\nNXB: ").append(receipt.getProvider())
                    .append("\nTên sách: ").append(item.getBookTitle())
                    .append("\nSố lượng: ").append(item.getQuantity())
                    .append("\nGiá nhập: ").append(String.format("%,.0fđ", item.getPrice()))
                    .append("\n-----------------------------");
        }

        new AlertDialog.Builder(getContext())
                .setTitle("📦 Phiếu nhập")
                .setMessage("Ngày nhập: " + receipt.getDate() +
                        "\n" + details +
                        "\n\n💰 Tổng tiền: " + String.format("%,.0fđ", receipt.getTotal()))
                .setPositiveButton("Đóng", null)
                .show();
    }


    // ===================== XÓA PHIẾU =====================
    private void deleteImport(int position) {
        ImportReceipt receipt = importList.get(position);
        new AlertDialog.Builder(getContext())
                .setTitle("Xóa phiếu nhập?")
                .setMessage("Bạn có chắc muốn xóa phiếu nhập từ " + receipt.getProvider() + "?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    dbHelper.deleteImportReceipt(receipt.getId());
                    importList.remove(position);
                    adapter.notifyItemRemoved(position);
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}
