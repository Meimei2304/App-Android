package com.example.bookagent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ImportAdapter extends RecyclerView.Adapter<ImportAdapter.ImportViewHolder> {

    private List<ImportReceipt> receipts;
    private OnDetailListener detailListener;
    private OnDeleteListener deleteListener;

    public interface OnDetailListener {
        void onDetail(ImportReceipt receipt);
    }

    public interface OnDeleteListener {
        void onDelete(int position);
    }

    public ImportAdapter(List<ImportReceipt> receipts, OnDetailListener detailListener, OnDeleteListener deleteListener) {
        this.receipts = receipts;
        this.detailListener = detailListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ImportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_import_receipt, parent, false);
        return new ImportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImportViewHolder holder, int position) {
        ImportReceipt receipt = receipts.get(position);
        holder.txtProvider.setText(receipt.getProvider());
        holder.txtDate.setText("Ngày: " + receipt.getDate());
        holder.txtTotal.setText("Tổng: " + String.format("%,.0fđ", receipt.getTotal()));

        holder.btnDetail.setOnClickListener(v -> detailListener.onDetail(receipt));
        holder.btnDelete.setOnClickListener(v -> deleteListener.onDelete(position));
    }

    @Override
    public int getItemCount() {
        return receipts.size();
    }

    static class ImportViewHolder extends RecyclerView.ViewHolder {
        TextView txtProvider, txtDate, txtTotal;
        ImageButton btnDetail, btnDelete;

        ImportViewHolder(View itemView) {
            super(itemView);
            txtProvider = itemView.findViewById(R.id.txtImportProvider);
            txtDate = itemView.findViewById(R.id.txtImportDate);
            txtTotal = itemView.findViewById(R.id.txtImportTotal);
            btnDetail = itemView.findViewById(R.id.btnDetailImport);
            btnDelete = itemView.findViewById(R.id.btnDeleteImport);
        }
    }
}
