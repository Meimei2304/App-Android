package com.example.bookagent;

public class ImportItem {
    private String bookTitle;
    private int quantity;
    private double price;
    private double subtotal;

    public ImportItem(String bookTitle, int quantity, double price) {
        this.bookTitle = bookTitle;
        this.quantity = quantity;
        this.price = price;
        this.subtotal = quantity * price;
    }

    public String getBookTitle() { return bookTitle; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public double getSubtotal() { return subtotal; }
}
