package com.example.bookagent;

import java.util.List;

public class ImportReceipt {
    private int id;
    private String provider;
    private String date;
    private double total;
    private List<ImportItem> items;

    public ImportReceipt(String provider, String date, double total, List<ImportItem> items) {
        this.provider = provider;
        this.date = date;
        this.total = total;
        this.items = items;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getProvider() { return provider; }
    public String getDate() { return date; }
    public double getTotal() { return total; }
    public List<ImportItem> getItems() { return items; }
}
