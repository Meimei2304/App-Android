package com.example.bookagent;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottomNav);

        // Giao diện mặc định khi mở app
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, new BookActivity())
                .commit();

        // Lắng nghe sự kiện chọn tab
        nav.setOnItemSelectedListener(menuItem -> {
            Fragment selected = null;
            int id = menuItem.getItemId();

            if (id == R.id.nav_books) {
                selected = new BookActivity();
            } else if (id == R.id.nav_import) {
                selected = new ImportActivity();
            } else if (id == R.id.nav_sale) {
                selected = new SaleActivity();
            } else if (id == R.id.nav_stats) {
                selected = new StatisticsActivity();
            } else if (id == R.id.nav_user) {
                selected = new ProfileActivity();
            }

            if (selected != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainer, selected)
                        .commit();
            }

            return true;
        });
    }
}
