package com.example.bookagent;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaleActivity extends Fragment {

    private RecyclerView rvBooks;
    private EditText edtSearch;
    private DatabaseHelper dbHelper;
    private List<Book> allBooks = new ArrayList<>();
    private List<Book> displayBooks = new ArrayList<>();
    private List<CartItem> cart = new ArrayList<>();
    private BookSaleAdapter bookSaleAdapter;
    private DecimalFormat df = new DecimalFormat("#,###");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_sale, container, false);

        dbHelper = new DatabaseHelper(getContext());
        rvBooks = view.findViewById(R.id.rvBooksForSale);
        edtSearch = view.findViewById(R.id.edtSearchSale);
        Button btnOpenCart = view.findViewById(R.id.btnOpenCart);

        // Load dữ liệu sách
        allBooks = dbHelper.getAllBooks();
        displayBooks.clear();
        displayBooks.addAll(allBooks);

        // Adapter danh sách sách
        bookSaleAdapter = new BookSaleAdapter(displayBooks, (position, qtySelected) -> {
            Book b = displayBooks.get(position);
            if (qtySelected <= 0) {
                Toast.makeText(getContext(), "Chọn số lượng > 0", Toast.LENGTH_SHORT).show();
                return;
            }
            if (qtySelected > b.getQuantity()) {
                Toast.makeText(getContext(), "Không đủ tồn kho", Toast.LENGTH_SHORT).show();
                return;
            }
            addToCart(b, qtySelected);
        });

        rvBooks.setLayoutManager(new LinearLayoutManager(getContext()));
        rvBooks.setAdapter(bookSaleAdapter);

        // Nút mở giỏ hàng
        btnOpenCart.setOnClickListener(v -> openCartDialog());

        // Tìm kiếm
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                filterBooks(s.toString().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    //Tìm kiếm sách
    private void filterBooks(String keyword) {
        displayBooks.clear();
        if (keyword.isEmpty()) {
            displayBooks.addAll(allBooks);
        } else {
            for (Book b : allBooks) {
                if (b.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                    displayBooks.add(b);
                }
            }
        }
        bookSaleAdapter.notifyDataSetChanged();
    }

    //Thêm vào giỏ hàng
    private void addToCart(Book b, int qty) {
        for (CartItem item : cart) {
            if (item.title.equals(b.getTitle())) {
                int newQty = item.quantity + qty;
                if (newQty > b.getQuantity()) {
                    Toast.makeText(getContext(), "Vượt quá tồn kho", Toast.LENGTH_SHORT).show();
                    return;
                }
                item.quantity = newQty;
                Toast.makeText(getContext(), "Đã cập nhật số lượng trong giỏ", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        cart.add(new CartItem(b.getTitle(), qty, b.getPrice()));
        Toast.makeText(getContext(), "Đã thêm vào giỏ", Toast.LENGTH_SHORT).show();
    }

    //Hiển thị dialog giỏ hàng
    private void openCartDialog() {
        if (cart.isEmpty()) {
            Toast.makeText(getContext(), "Giỏ hàng trống", Toast.LENGTH_SHORT).show();
            return;
        }

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_cart, null);
        RecyclerView rvCartDialog = dialogView.findViewById(R.id.rvCartDialog);
        TextView tvCartTotal = dialogView.findViewById(R.id.tvCartTotal);
        Button btnConfirmSale = dialogView.findViewById(R.id.btnConfirmSale);

        //Dùng mảng 1 phần tử để giữ adapter có thể truy cập trong lambda
        final CartAdapter[] dialogAdapter = new CartAdapter[1];

        dialogAdapter[0] = new CartAdapter(cart, new CartAdapter.CartActions() {
            @Override
            public void onRemove(int pos) {
                cart.remove(pos);
                dialogAdapter[0].notifyItemRemoved(pos);
                refreshTotalDialog(tvCartTotal);
            }

            @Override
            public void onUpdateQty(int pos, int newQty) {
                String title = cart.get(pos).title;
                Book bookDb = dbHelper.getBookByTitle(title);
                if (bookDb != null && newQty <= bookDb.getQuantity()) {
                    cart.get(pos).quantity = newQty;
                    dialogAdapter[0].notifyItemChanged(pos);
                    refreshTotalDialog(tvCartTotal);
                } else {
                    Toast.makeText(getContext(), "Không đủ tồn", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rvCartDialog.setLayoutManager(new LinearLayoutManager(getContext()));
        rvCartDialog.setAdapter(dialogAdapter[0]);
        refreshTotalDialog(tvCartTotal);

        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setView(dialogView)
                .create();

        btnConfirmSale.setOnClickListener(v -> {
            dialog.dismiss();
            confirmSale();
        });

        dialog.show();
    }


    private void refreshTotalDialog(TextView tv) {
        double total = 0;
        for (CartItem c : cart) total += c.quantity * c.price;
        tv.setText("Tổng: " + df.format(total) + "đ");
    }

    //Xác nhận bán hàng
    private void confirmSale() {
        if (cart.isEmpty()) {
            Toast.makeText(getContext(), "Giỏ hàng trống", Toast.LENGTH_SHORT).show();
            return;
        }

        double total = 0;
        StringBuilder detail = new StringBuilder();
        for (CartItem c : cart) {
            total += c.quantity * c.price;
            detail.append(c.title).append(" x").append(c.quantity).append("  ");
        }

        final double totalFinal = total;

        new AlertDialog.Builder(getContext())
                .setTitle("Xác nhận bán hàng")
                .setMessage("Bạn sẽ bán:\n" + detail.toString() +
                        "\n\nTổng: " + df.format(totalFinal) + "đ\nXác nhận?")
                .setPositiveButton("Xác nhận", (dialog, which) -> {
                    String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
                    long hoadonId = dbHelper.addInvoice(now, totalFinal);
                    if (hoadonId <= 0) {
                        Toast.makeText(getContext(), "Lỗi lưu hoá đơn", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean ok = true;
                    for (CartItem c : cart) {
                        double subtotal = c.quantity * c.price;
                        long idct = dbHelper.addInvoiceDetail(hoadonId, c.title, c.quantity, c.price, subtotal);
                        if (idct <= 0) ok = false;
                        Book b = dbHelper.getBookByTitle(c.title);
                        if (b != null) {
                            int newQty = b.getQuantity() - c.quantity;
                            if (newQty < 0) newQty = 0;
                            dbHelper.updateBookQuantityByTitle(b.getTitle(), newQty);
                        }
                    }

                    if (ok) {
                        Toast.makeText(getContext(), "Bán hàng thành công", Toast.LENGTH_SHORT).show();
                        allBooks = dbHelper.getAllBooks();
                        displayBooks.clear();
                        displayBooks.addAll(allBooks);
                        bookSaleAdapter.notifyDataSetChanged();
                        cart.clear();
                    } else {
                        Toast.makeText(getContext(), "Có lỗi khi lưu chi tiết", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    //Lớp CartItem
    public static class CartItem {
        public String title;
        public int quantity;
        public double price;

        public CartItem(String t, int q, double p) {
            this.title = t;
            this.quantity = q;
            this.price = p;
        }
    }
}
