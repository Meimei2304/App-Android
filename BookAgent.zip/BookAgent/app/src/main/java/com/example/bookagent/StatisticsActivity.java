package com.example.bookagent;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class StatisticsActivity extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_statistics, container, false);

        ListView listMenu = view.findViewById(R.id.listStatisticsMenu);

        String[] menuItems = {
                "Tổng doanh thu",
                "Thống kê doanh thu",
                "Cập nhật dữ liệu",
                "Xuất báo cáo doanh thu"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_list_item_1,
                menuItems
        );
        listMenu.setAdapter(adapter);

        return view;
    }
}
